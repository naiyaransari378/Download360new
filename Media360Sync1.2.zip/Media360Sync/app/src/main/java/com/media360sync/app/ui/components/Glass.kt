package com.media360sync.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette

/** Deep night background with slowly drifting aurora light. */
@Composable
fun AuroraBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val drift by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "drift"
    )
    val k = if (Palette.isDark) 1f else 0.75f
    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            blob(Offset(w * (0.1f + 0.15f * drift), h * 0.1f), w * 0.8f, Palette.Violet.copy(alpha = 0.26f * k))
            blob(Offset(w * (1f - 0.2f * drift), h * (0.36f + 0.06f * drift)), w * 0.7f, Palette.Sky.copy(alpha = 0.2f * k))
            blob(Offset(w * 0.25f, h * (0.92f - 0.08f * drift)), w * 0.85f, Palette.Indigo.copy(alpha = 0.18f * k))
        }
        content()
    }
}

private fun DrawScope.blob(center: Offset, radius: Float, color: Color) =
    drawCircle(Brush.radialGradient(listOf(color, Color.Transparent), center, radius), radius, center)


/** Frosted glass surface: translucent fill + light-catching gradient edge. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 28.dp,
    padding: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier.softSurface(RoundedCornerShape(corner)).padding(padding), content = content)
}

/**
 * Night: frosted glass. Day: soft white "neumorphic" surface floating on a
 * violet-tinted shadow (like the reference design).
 */
@Composable
fun Modifier.softSurface(shape: Shape, elevation: Dp = 14.dp, solid: Boolean = false): Modifier =
    if (Palette.isDark) {
        this.clip(shape)
            .then(if (solid) Modifier.background(Palette.Panel) else Modifier)
            .background(Brush.verticalGradient(listOf(Palette.GlassTop, Palette.GlassBottom)))
            .border(
                1.dp,
                Brush.linearGradient(listOf(Palette.GlassEdge, Palette.Ink.copy(alpha = 0.05f), Palette.Violet.copy(alpha = 0.3f))),
                shape
            )
    } else {
        this.shadow(elevation, shape, ambientColor = Palette.Violet.copy(alpha = 0.22f), spotColor = Palette.Violet.copy(alpha = 0.28f))
            .clip(shape)
            .background(Color.White.copy(alpha = 0.96f))
            .border(1.dp, Color.White, shape)
    }

/** Round sun/moon button. Moon in Day (tap for Night), sun in Night (tap for Day). */
@Composable
fun ThemeToggleButton(dark: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(40.dp).softSurface(CircleShape, 8.dp).clickable(onClick = onToggle),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = dark,
            transitionSpec = { (fadeIn(tween(200)) + scaleIn(tween(250))) togetherWith (fadeOut(tween(150)) + scaleOut(tween(150))) },
            label = "themeIcon",
        ) { isDark ->
            Icon(
                if (isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                contentDescription = if (isDark) "Switch to day mode" else "Switch to night mode",
                tint = if (isDark) Palette.Amber else Palette.TextHi,
                modifier = Modifier.size(21.dp),
            )
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier, color: Color = Palette.Label) =
    Text(
        text.uppercase(), modifier = modifier, color = color,
        fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
    )

@Composable
fun StatusPill(text: String, color: Color) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(color.copy(alpha = 0.14f)).border(1.dp, color.copy(alpha = 0.45f), shape)
            .padding(horizontal = 16.dp, vertical = 7.dp)
    ) { Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
fun GradientButton(
    text: String, icon: ImageVector?, onClick: () -> Unit,
    modifier: Modifier = Modifier, enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier.height(50.dp)
            .shadow(if (enabled && !Palette.isDark) 10.dp else 0.dp, shape, ambientColor = Palette.Violet, spotColor = Palette.Violet)
            .clip(shape)
            .background(if (enabled) BrandBrush else SolidColor(Palette.Ink.copy(alpha = 0.08f)))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun GlassButton(
    text: String, icon: ImageVector?, onClick: () -> Unit,
    modifier: Modifier = Modifier, enabled: Boolean = true, tint: Color = Palette.TextHi,
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier.height(50.dp).softSurface(shape, 8.dp)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        val c = if (enabled) tint else Palette.TextLow
        if (icon != null) { Icon(icon, null, tint = c, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = c, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Pill chips, one selected. Selected chip carries the brand gradient. */
@Composable
fun ChoiceChips(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val shape = RoundedCornerShape(50)
            val on = i == selected
            val textColor by animateColorAsState(if (on) Color.White else Palette.TextMid, label = "chip")
            Box(
                Modifier.clip(shape)
                    .background(if (on) BrandBrush else SolidColor(Palette.Ink.copy(alpha = 0.05f)))
                    .border(1.dp, if (on) Color.Transparent else Palette.Ink.copy(alpha = 0.1f), shape)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            ) { Text(label, color = textColor, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        SectionLabel(label, Modifier.weight(1f))
        Text(
            value, color = Palette.TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            textAlign = TextAlign.End, modifier = Modifier.weight(1.2f),
        )
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Palette.TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (subtitle != null) Text(subtitle, color = Palette.TextLow, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = Palette.Violet,
                uncheckedThumbColor = Palette.TextLow, uncheckedTrackColor = Palette.Ink.copy(alpha = 0.06f),
                uncheckedBorderColor = Palette.Ink.copy(alpha = 0.15f),
            ),
        )
    }
}

@Composable
fun ScreenHeader(eyebrow: String, title: String, subtitle: String?) {
    Column {
        SectionLabel(eyebrow, color = Palette.Violet)
        Spacer(Modifier.height(10.dp))
        Text(title, color = Palette.TextHi, fontSize = 27.sp, fontWeight = FontWeight.Black, lineHeight = 32.sp)
        if (subtitle != null) {
            Spacer(Modifier.height(10.dp))
            Text(subtitle, color = Palette.TextMid, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}
