package com.media360sync.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkInfo
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.QueueItem
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.ScreenHeader
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt
import com.media360sync.app.util.Platform

@Composable
fun QueueScreen(vm: MainViewModel, padding: PaddingValues) {
    val items by vm.queue.collectAsStateWithLifecycle()
    val active = items.filter { it.isActive }
        .sortedWith(compareBy<QueueItem>({ it.state != WorkInfo.State.RUNNING }, { it.time }))
    val done = items.filterNot { it.isActive }.sortedByDescending { it.time }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding()
        ),
    ) {
        item {
            ScreenHeader("Downloads", "Queue", "${active.size} active • ${done.size} finished")
            Spacer(Modifier.height(20.dp))
        }

        if (items.isEmpty()) item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Nothing in the queue", color = Palette.TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Paste a link on Home and tap the ball. Add several links in a row and they download one after another.",
                    color = Palette.TextMid, lineHeight = 20.sp
                )
            }
        }

        if (active.isNotEmpty()) {
            item { SectionLabel("Active"); Spacer(Modifier.height(10.dp)) }
            items(active, key = { it.id }) { item ->
                ActiveRow(item) { vm.cancel(item.id) }
                Spacer(Modifier.height(12.dp))
            }
            item { Spacer(Modifier.height(10.dp)) }
        }

        if (done.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionLabel("Recent", Modifier.weight(1f))
                    Text(
                        "Clear", color = Palette.Violet, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.clearFinished() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
            items(done, key = { it.id }) { item ->
                DoneRow(item) { vm.retry(item) }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun PlatformLabel(p: Platform, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        val dot = if (p == Platform.TIKTOK) Palette.TextHi else Color(p.color)
        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(8.dp))
        Text(p.label, color = Palette.TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ActiveRow(item: QueueItem, onCancel: () -> Unit) {
    val running = item.state == WorkInfo.State.RUNNING
    GlassCard(Modifier.fillMaxWidth(), corner = 22.dp, padding = 16.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PlatformLabel(item.platform, Modifier.weight(1f))
            Text(
                when {
                    !running -> "Waiting"
                    item.progress == null -> "Starting…"
                    else -> "${item.progress.toInt()}%" + Fmt.eta(item.eta).let { if (it.isEmpty()) "" else " • $it" }
                },
                color = if (running) Palette.Violet else Palette.TextLow, fontWeight = FontWeight.SemiBold, fontSize = 14.sp
            )
            IconButton(onClick = onCancel) { Icon(Icons.Rounded.Close, "Cancel", tint = Palette.TextLow) }
        }
        Text(item.url, color = Palette.TextLow, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (running) {
            Spacer(Modifier.height(12.dp))
            val p = item.progress
            if (p == null) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                    color = Palette.Violet, trackColor = Palette.Ink.copy(alpha = 0.08f)
                )
            } else {
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(Palette.Ink.copy(alpha = 0.08f))) {
                    Box(Modifier.fillMaxWidth((p / 100f).coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(BrandBrush))
                }
            }
        }
    }
}

@Composable
private fun DoneRow(item: QueueItem, onRetry: () -> Unit) {
    val ok = item.state == WorkInfo.State.SUCCEEDED
    GlassCard(Modifier.fillMaxWidth(), corner = 22.dp, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null,
                tint = if (ok) Palette.Mint else Palette.Rose, modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (ok && item.title.isNotBlank()) item.title else item.platform.label,
                    color = Palette.TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (ok) "Saved to your gallery" else item.error ?: "Failed",
                    color = if (ok) Palette.TextLow else Palette.Rose, fontSize = 12.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
            if (!ok && item.url.isNotBlank()) {
                IconButton(onClick = onRetry) { Icon(Icons.Rounded.Refresh, "Retry", tint = Palette.Violet) }
            }
        }
    }
}
