package com.media360sync.app.util

import android.content.Context
import android.webkit.CookieManager
import java.io.File

/** Sites the user can sign in to, so yt-dlp can fetch stories / private posts. */
enum class LoginSite(val label: String, val domain: String, val loginUrl: String, val authCookie: String, val color: Long) {
    INSTAGRAM("Instagram", "instagram.com", "https://www.instagram.com/accounts/login/", "sessionid", 0xFFE1306C),
    FACEBOOK("Facebook", "facebook.com", "https://m.facebook.com/login/", "c_user", 0xFF4C8DFF),
    X("X / Twitter", "x.com", "https://x.com/i/flow/login", "auth_token", 0xFF9CA3AF),
    TIKTOK("TikTok", "tiktok.com", "https://www.tiktok.com/login", "sessionid", 0xFF25F4EE),
    REDDIT("Reddit", "reddit.com", "https://www.reddit.com/login/", "reddit_session", 0xFFFF6A2B),
}

/**
 * Login happens inside a WebView; we export its cookies to a Netscape
 * cookies.txt that yt-dlp reads with --cookies. Nothing leaves the phone.
 */
object CookieStore {
    fun file(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    fun siteFor(p: Platform): LoginSite? = when (p) {
        Platform.INSTAGRAM -> LoginSite.INSTAGRAM
        Platform.FACEBOOK -> LoginSite.FACEBOOK
        Platform.X -> LoginSite.X
        Platform.TIKTOK -> LoginSite.TIKTOK
        Platform.REDDIT -> LoginSite.REDDIT
        else -> null
    }

    private fun cookies(site: LoginSite): Map<String, String> {
        val raw = runCatching { CookieManager.getInstance().getCookie("https://www.${site.domain}") }.getOrNull()
            ?: return emptyMap()
        return raw.split(";").mapNotNull { part ->
            val i = part.indexOf('=')
            if (i <= 0) null else part.substring(0, i).trim() to part.substring(i + 1).trim()
        }.toMap()
    }

    fun isSignedIn(site: LoginSite): Boolean = !cookies(site)[site.authCookie].isNullOrEmpty()

    /** Writes every signed-in site's cookies to cookies.txt (or deletes it if none). */
    fun export(ctx: Context) {
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val lines = buildList {
            LoginSite.entries.forEach { site ->
                cookies(site).forEach { (name, value) ->
                    add(".${site.domain}\tTRUE\t/\tTRUE\t$expiry\t$name\t$value")
                }
            }
        }
        val f = file(ctx)
        if (lines.isEmpty()) f.delete()
        else f.writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
    }

    fun signOut(ctx: Context, site: LoginSite) {
        val cm = CookieManager.getInstance()
        val expired = "Expires=Thu, 01 Jan 1970 00:00:00 GMT"
        cookies(site).keys.forEach { name ->
            listOf("https://www.${site.domain}", "https://${site.domain}").forEach { url ->
                cm.setCookie(url, "$name=; $expired; Path=/; Domain=.${site.domain}")
                cm.setCookie(url, "$name=; $expired; Path=/")
            }
        }
        cm.flush()
        export(ctx)
    }
}
