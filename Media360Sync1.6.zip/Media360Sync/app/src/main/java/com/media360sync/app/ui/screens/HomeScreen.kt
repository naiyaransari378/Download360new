package com.media360sync.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.AUDIO_FORMATS
import com.media360sync.app.data.AppSettings
import com.media360sync.app.data.Quality
import com.media360sync.app.engine.EngineStatus
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.Phase
import com.media360sync.app.ui.components.ChoiceChips
import com.media360sync.app.ui.components.Football3D
import com.media360sync.app.ui.components.GlassButton
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.GradientButton
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.components.ThemeToggleButton
import com.media360sync.app.ui.components.softSurface
import com.media360sync.app.ui.theme.ModeBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt
import com.media360sync.app.util.Platform
import com.media360sync.app.util.UrlUtils

@Composable
fun HomeScreen(vm: MainViewModel, padding: PaddingValues) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val engine by vm.engine.collectAsStateWithLifecycle()
    val dl by vm.download.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current
    val detected = UrlUtils.extractUrl(vm.url)?.let { UrlUtils.detect(it) }
    val dark = Palette.isDark

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 20.dp)
    ) {
        // ---------- Header ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionLabel("Media360Sync", Modifier.weight(1f), color = Palette.VioletDeep.takeIf { !dark } ?: Palette.Violet)
            OnlinePill(engine.status)
            Spacer(Modifier.width(12.dp))
            ThemeToggleButton(dark, { vm.toggleTheme(dark) })
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Paste. Tap. It’s yours.", color = Palette.TextHi,
            fontSize = 26.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp
        )
        Spacer(Modifier.height(2.dp))
        Text("Works with 1,000+ sites", color = Palette.TextMid, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))

        // ---------- Clipboard suggestion ----------
        AnimatedVisibility(vm.clipboardSuggestion != null && vm.url.isBlank()) {
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 14.dp), corner = 22.dp, padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ContentPaste, null, tint = Palette.Violet)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Link on your clipboard", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
                        Text(
                            vm.clipboardSuggestion.orEmpty(), color = Palette.TextLow, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        "Use", color = Palette.Violet, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.useClipboard() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    IconButton(onClick = vm::dismissClipboard) { Icon(Icons.Rounded.Close, "Dismiss", tint = Palette.TextLow) }
                }
            }
        }

        // ---------- Input card ----------
        GlassCard(Modifier.fillMaxWidth(), corner = 26.dp, padding = 14.dp) {
            LinkField(
                value = vm.url,
                onChange = vm::onUrlChange,
                onPaste = { clipboard.getText()?.text?.let(vm::onUrlChange) },
                onClear = { vm.onUrlChange("") },
                onGo = { focus.clearFocus(); vm.startDownload() },
            )
            Spacer(Modifier.height(12.dp))
            ModeSwitch(settings.audioOnly) { audio -> vm.updateSettings { it.copy(audioOnly = audio) } }
            Spacer(Modifier.height(12.dp))
            QualityRow(settings, vm)
            Spacer(Modifier.height(12.dp))
            PlatformChips(detected)
        }

        // ---------- The ball ----------
        BoxWithConstraints(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
            Football3D(
                modifier = Modifier.size(min(maxWidth * 0.66f, 250.dp)),
                progress = if (dl.phase == Phase.RUNNING) dl.progress ?: 0f else null,
                busy = dl.phase == Phase.RUNNING || dl.phase == Phase.QUEUED,
                success = dl.phase == Phase.DONE,
                error = dl.phase == Phase.FAILED,
                haptics = settings.haptics,
                onTap = { focus.clearFocus(); vm.startDownload() },
            )
        }

        StatusBlock(vm, engine.status, detected)

        if (dl.phase == Phase.DONE) {
            Spacer(Modifier.height(12.dp))
            GradientButton("Play now", Icons.Rounded.PlayArrow, vm::playLatest, Modifier.fillMaxWidth())
        }
        val needsLogin = dl.loginSite
        if (dl.phase == Phase.FAILED && needsLogin != null) {
            Spacer(Modifier.height(12.dp))
            GradientButton(
                "Sign in to ${needsLogin.label} & retry", Icons.Rounded.LockOpen,
                { vm.openLogin(needsLogin, dl.url) }, Modifier.fillMaxWidth()
            )
        }
        if (dl.phase == Phase.RUNNING) {
            Spacer(Modifier.height(12.dp))
            GlassButton("Cancel download", Icons.Rounded.Stop, vm::cancelDownload, Modifier.fillMaxWidth(), tint = Palette.Rose)
        }
    }
}

@Composable
private fun OnlinePill(status: EngineStatus) {
    val (label, color) = when (status) {
        EngineStatus.READY -> "Online" to Palette.Mint
        EngineStatus.UPDATING -> "Updating" to Palette.Sky
        EngineStatus.STARTING -> "Starting" to Palette.Amber
        EngineStatus.ERROR -> "Offline" to Palette.Rose
    }
    Row(
        Modifier.height(40.dp).softSurface(RoundedCornerShape(50), 8.dp).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(7.dp))
        Text(label, color = Palette.TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun LinkField(
    value: String, onChange: (String) -> Unit,
    onPaste: () -> Unit, onClear: () -> Unit, onGo: () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    val empty = value.isEmpty()
    Row(
        Modifier.fillMaxWidth().height(54.dp).clip(shape).background(Palette.Field)
            .border(1.dp, Palette.Ink.copy(alpha = 0.08f), shape)
            .padding(start = 14.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Link, null, tint = Palette.TextHi, modifier = Modifier.size(22.dp).rotate(-45f))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (empty) Text("Paste a video link", color = Palette.TextLow, fontSize = 15.sp, maxLines = 1)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Palette.TextHi, fontSize = 15.sp),
                cursorBrush = SolidColor(Palette.Violet),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGo() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.width(8.dp))
        val bg by animateColorAsState(if (empty) Palette.VioletDeep else Palette.Ink.copy(alpha = 0.07f), label = "pasteBg")
        Box(
            Modifier.height(42.dp).clip(RoundedCornerShape(14.dp)).background(bg)
                .clickable { if (empty) onPaste() else onClear() }.padding(horizontal = 18.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (empty) "Paste" else "Clear", color = if (empty) Color.White else Palette.TextHi,
                fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
        }
    }
}

@Composable
private fun ModeSwitch(audioOnly: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().height(48.dp).clip(shape).background(Palette.Ink.copy(alpha = 0.04f))
            .border(1.dp, Palette.Ink.copy(alpha = 0.06f), shape).padding(4.dp)
    ) {
        listOf(
            Triple(false, "Video", Icons.Rounded.Videocam),
            Triple(true, "Audio only", Icons.Rounded.Headphones),
        ).forEach { (audio, label, icon) ->
            ModeSegment(label, icon, on = audio == audioOnly, modifier = Modifier.weight(1f)) { onChange(audio) }
        }
    }
}

@Composable
private fun ModeSegment(label: String, icon: ImageVector, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint by animateColorAsState(if (on) Color.White else Palette.TextHi, label = "seg")
    Row(
        modifier.fillMaxHeight().clip(RoundedCornerShape(12.dp))
            .background(if (on) ModeBrush else SolidColor(Color.Transparent))
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = tint, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlatformChips(detected: Platform?) {
    val moreActive = detected != null && detected !in listOf(Platform.YOUTUBE, Platform.INSTAGRAM, Platform.TIKTOK)
    FlowRow(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PlatformChip("YouTube", Color(Platform.YOUTUBE.color), detected == Platform.YOUTUBE)
        PlatformChip("Instagram", Color(Platform.INSTAGRAM.color), detected == Platform.INSTAGRAM)
        PlatformChip("TikTok", Palette.TextHi, detected == Platform.TIKTOK)
        PlatformChip(if (moreActive) detected!!.label else "+1,000 more", Palette.Cyan, moreActive)
    }
}

@Composable
private fun PlatformChip(label: String, dot: Color, active: Boolean) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.height(34.dp).softSurface(shape, if (active) 6.dp else 3.dp)
            .then(if (active) Modifier.border(1.5.dp, dot.copy(alpha = 0.7f), shape) else Modifier)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(7.dp))
        Text(label, color = Palette.TextHi, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Quality (video) or format (audio) — right inside the top card. */
@Composable
private fun QualityRow(settings: AppSettings, vm: MainViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (settings.audioOnly) "Format" else "Quality",
            color = Palette.TextMid, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(58.dp)
        )
        if (settings.audioOnly) {
            ChoiceChips(
                AUDIO_FORMATS.map { it.uppercase() },
                AUDIO_FORMATS.indexOf(settings.audioFormat).coerceAtLeast(0),
                { i -> vm.updateSettings { it.copy(audioFormat = AUDIO_FORMATS[i]) } },
                Modifier.weight(1f),
            )
        } else {
            ChoiceChips(
                Quality.entries.map { it.label },
                settings.quality.ordinal,
                { i -> vm.updateSettings { it.copy(quality = Quality.entries[i]) } },
                Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun StatusBlock(vm: MainViewModel, engine: EngineStatus, detected: Platform?) {
    val dl by vm.download.collectAsStateWithLifecycle()
    val (headline, detail, color) = when {
        engine == EngineStatus.STARTING -> Triple("Warming up the engine…", "First launch unpacks yt-dlp. One moment.", Palette.Amber)
        engine == EngineStatus.ERROR -> Triple("Engine offline", "Restart the app. If it continues, reinstall.", Palette.Rose)
        dl.phase == Phase.RUNNING -> {
            val pct = dl.progress?.let { "${it.toInt()}%" } ?: "Starting"
            val eta = Fmt.eta(dl.eta).let { if (it.isEmpty()) "" else " • $it left" }
            val queue = if (dl.waiting > 0) " • ${dl.waiting} queued" else ""
            Triple("$pct$eta", "Downloading from ${dl.platform.ifEmpty { "the web" }}$queue", Palette.Violet)
        }
        dl.phase == Phase.QUEUED -> Triple("Queued", "${dl.waiting} waiting for a connection", Palette.Violet)
        dl.phase == Phase.DONE -> Triple("Saved to your gallery", dl.title, Palette.Mint)
        dl.phase == Phase.FAILED -> Triple("Couldn’t download", dl.error.orEmpty(), Palette.Rose)
        vm.url.isBlank() -> Triple("Tap the ball to download", "Or share a link to this app", Palette.TextHi)
        else -> Triple("Ready — tap the ball", "${detected?.label ?: "Web"} link detected", Palette.TextHi)
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(headline, color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (detail.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                detail, color = Palette.TextMid, fontSize = 14.sp, textAlign = TextAlign.Center,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
    }
}
