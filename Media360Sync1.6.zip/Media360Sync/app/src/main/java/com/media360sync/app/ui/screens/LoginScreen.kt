package com.media360sync.app.ui.screens

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.CookieStore
import com.media360sync.app.util.LoginSite
import kotlinx.coroutines.delay

/** The site's own login page. Closes by itself once the login cookie appears. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(site: LoginSite, onDone: (signedIn: Boolean) -> Unit) {
    val done by rememberUpdatedState(onDone)
    var loading by remember { mutableStateOf(true) }
    var finished by remember { mutableStateOf(false) }
    fun finish(ok: Boolean) {
        if (finished) return
        finished = true
        CookieManager.getInstance().flush()
        done(ok)
    }

    BackHandler { finish(CookieStore.isSignedIn(site)) }

    // Single-page apps (Instagram, X) don't always fire page events after login
    LaunchedEffect(site) {
        while (!finished) {
            delay(1200)
            if (CookieStore.isSignedIn(site)) { delay(600); finish(true) }
        }
    }

    val bars = WindowInsets.systemBars.asPaddingValues()
    Column(Modifier.fillMaxSize().background(Palette.Bg).padding(top = bars.calculateTopPadding())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { finish(CookieStore.isSignedIn(site)) }) {
                Icon(Icons.Rounded.Close, "Close", tint = Palette.TextHi)
            }
            Column(Modifier.weight(1f)) {
                Text("Sign in to ${site.label}", color = Palette.TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Lock, null, tint = Palette.Mint, modifier = Modifier.padding(end = 4.dp).width(12.dp))
                    Text(
                        "You sign in on ${site.domain} itself. Your password never reaches this app.",
                        color = Palette.TextLow, fontSize = 11.sp, maxLines = 2
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Palette.Violet)
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { loading = true }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            loading = false
                            if (CookieStore.isSignedIn(site)) finish(true)
                        }
                    }
                    loadUrl(site.loginUrl)
                }
            },
            onRelease = { it.stopLoading(); it.destroy() },
            modifier = Modifier.fillMaxWidth().weight(1f).padding(bottom = bars.calculateBottomPadding()),
        )
    }
}
