package com.media360sync.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.ui.components.AuroraBackground
import com.media360sync.app.ui.components.MiniPlayer
import com.media360sync.app.ui.components.softSurface
import com.media360sync.app.ui.screens.EngineScreen
import com.media360sync.app.ui.screens.HomeScreen
import com.media360sync.app.ui.screens.LibraryScreen
import com.media360sync.app.ui.screens.NowPlayingScreen
import com.media360sync.app.ui.screens.QueueScreen
import com.media360sync.app.ui.screens.SettingsScreen
import com.media360sync.app.ui.theme.ModeBrush
import com.media360sync.app.ui.theme.Palette

@Suppress("DEPRECATION")
enum class Tab(val label: String, val icon: ImageVector, val iconSelected: ImageVector) {
    HOME("Home", Icons.Outlined.Home, Icons.Rounded.Home),
    LIBRARY("Library", Icons.Outlined.Folder, Icons.Rounded.Folder),
    QUEUE("Queue", Icons.Outlined.FormatListBulleted, Icons.Rounded.FormatListBulleted),
    SETTINGS("Settings", Icons.Outlined.Settings, Icons.Rounded.Settings),
    ENGINE("Engine", Icons.Outlined.Settings, Icons.Rounded.Settings), // opened from Settings
}

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    LaunchedEffect(vm.homeRequests) { if (vm.homeRequests > 0) tab = Tab.HOME }

    val ps by vm.player.state.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val activeDownloads = queue.count { it.isActive }
    val hasMedia = ps.current != null
    val fullPlayer = vm.playerExpanded && hasMedia

    BackHandler(enabled = fullPlayer) { if (vm.videoFullscreen) vm.videoFullscreen = false else vm.collapsePlayer() }
    BackHandler(enabled = !fullPlayer && tab == Tab.ENGINE) { tab = Tab.SETTINGS }
    BackHandler(enabled = !fullPlayer && tab != Tab.HOME && tab != Tab.ENGINE) { tab = Tab.HOME }

    AuroraBackground {
        val bars = WindowInsets.systemBars.asPaddingValues()
        val content = PaddingValues(
            top = bars.calculateTopPadding() + 16.dp,
            bottom = bars.calculateBottomPadding() + 120.dp + if (hasMedia) 76.dp else 0.dp,
        )
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "tabs",
        ) { t ->
            when (t) {
                Tab.HOME -> HomeScreen(vm, content)
                Tab.LIBRARY -> LibraryScreen(vm, content)
                Tab.QUEUE -> QueueScreen(vm, content)
                Tab.SETTINGS -> SettingsScreen(vm, content, onOpenEngine = { tab = Tab.ENGINE })
                Tab.ENGINE -> EngineScreen(vm, content, onBack = { tab = Tab.SETTINGS })
            }
        }

        AnimatedVisibility(
            visible = hasMedia && !vm.playerExpanded,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = bars.calculateBottomPadding() + 104.dp, start = 18.dp, end = 18.dp),
        ) {
            MiniPlayer(
                ps,
                onOpen = vm::expandPlayer,
                onToggle = vm.player::togglePlay,
                onNext = vm.player::next,
                onClose = vm::closePlayer,
            )
        }

        BottomBar(
            selected = if (tab == Tab.ENGINE) Tab.SETTINGS else tab,
            queueBadge = activeDownloads,
            onSelect = { tab = it },
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = bars.calculateBottomPadding() + 14.dp, start = 18.dp, end = 18.dp)
        )

        AnimatedVisibility(
            visible = fullPlayer,
            enter = slideInVertically(tween(320)) { it },
            exit = slideOutVertically(tween(260)) { it },
        ) { NowPlayingScreen(vm) }
    }
}

@Composable
private fun BottomBar(selected: Tab, queueBadge: Int, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().height(80.dp).softSurface(RoundedCornerShape(32.dp), 18.dp).padding(7.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        listOf(Tab.HOME, Tab.LIBRARY, Tab.QUEUE, Tab.SETTINGS).forEach { t ->
            val on = t == selected
            val tint by animateColorAsState(if (on) Color.White else Palette.TextHi.copy(alpha = 0.85f), label = "navTint")
            Column(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp))
                    .background(if (on) ModeBrush else SolidColor(Color.Transparent))
                    .clickable { onSelect(t) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box {
                    Icon(if (on) t.iconSelected else t.icon, t.label, tint = tint, modifier = Modifier.size(28.dp))
                    if (t == Tab.QUEUE && queueBadge > 0) {
                        Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 8.dp, y = (-4).dp)
                                .size(18.dp).clip(CircleShape).background(Palette.Rose),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("$queueBadge", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(t.label, color = tint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
